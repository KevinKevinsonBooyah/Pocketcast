"""Foreground home-network host. Close the console to stop."""
import ctypes as C
import hmac
import ipaddress
import json
import os
import secrets
import socket
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import host
from monitor import MonitorCover

ROOT = Path(__file__).parent
lock = threading.RLock()
changed = threading.Condition(lock)
frame_number = 0
frame = b''
audio = b''
serial = 0
token = ''
pin = ''
last_guess = 0
last_frame = 0
owner = secrets.token_urlsafe(32)
cover = MonitorCover()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def reply(self, status, body=b'', mime='text/plain', sequence=None):
        self.send_response(status)
        self.send_header('Content-Type', mime)
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Content-Length', str(len(body)))
        if sequence is not None:
            self.send_header('X-Sequence', str(sequence))
        self.end_headers()
        self.wfile.write(body)

    def stream_frames(self):
        credential = self.headers.get('Authorization', '').encode()
        def authorized():
            return bool(token) and hmac.compare_digest(credential, ('Bearer '+token).encode())
        with lock:
            if not authorized():
                return self.reply(403)
        self.send_response(200)
        self.send_header('Content-Type', 'application/octet-stream')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.connection.settimeout(5)
        self.connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        previous = -1
        while True:
            with changed:
                changed.wait_for(lambda: frame_number != previous or not authorized(), timeout=2)
                if not authorized() or time.monotonic()-last_frame > 5:
                    return
                if previous == frame_number:
                    continue
                previous, image = frame_number, frame
            # Slow readers skip directly to the latest complete frame.
            self.wfile.write(len(image).to_bytes(4,'big') + image)

    def route(self):
        global frame_number, frame, audio, serial, token, pin, last_guess, last_frame
        local = self.server.local
        if self.headers.get('Host') != self.server.authority:
            return self.reply(403)
        if self.command == 'GET' and self.path == '/':
            page = ROOT / ('home-host.html' if local else 'home-player.html')
            return self.reply(200, page.read_bytes(), 'text/html; charset=utf-8')
        if not local and self.command == 'GET' and self.path == '/live':
            return self.stream_frames()
        data = b''
        if self.command == 'POST':
            if self.headers.get('Origin') != 'http://' + self.server.authority:
                return self.reply(403)
            size = int(self.headers.get('Content-Length','0'))
            if not 0 <= size <= 1500000:
                return self.reply(413)
            data = self.rfile.read(size)
        status, result, mime, sequence = 404, b'', 'text/plain', None
        with lock:
            credential = self.headers.get('Authorization','').encode()
            if local:
                if not hmac.compare_digest(credential, ('Bearer '+owner).encode()):
                    status = 403
                elif self.path == '/frame' and data:
                    frame, last_frame, status = data, time.monotonic(), 204
                    frame_number += 1
                    changed.notify_all()
                elif self.path == '/audio' and data:
                    audio, serial, status = data, serial+1, 204
                elif self.path == '/stop' and self.command == 'POST':
                    if cover.hidden:
                        cover.set_hidden(False)
                    host.session.release()
                    frame, audio, token, last_frame, status = b'', b'', '', 0, 204
                    changed.notify_all()
            elif self.path == '/pair' and self.command == 'POST':
                now = time.monotonic()
                if now-last_guess < 1:
                    status = 429
                elif now-last_frame > 3 or not frame:
                    status = 503
                else:
                    last_guess = now
                    if hmac.compare_digest(data,pin.encode()):
                        host.session.release()
                        token = secrets.token_urlsafe(32)
                        result, status = token.encode(), 200
                    else:
                        status = 403
            elif not token or not hmac.compare_digest(credential, ('Bearer '+token).encode()):
                status = 403
            elif time.monotonic()-last_frame > 3:
                status = 503
            elif self.path == '/monitor' and self.command == 'GET':
                status, result = 200, b'hidden' if cover.hidden else b'visible'
            elif self.path == '/monitor' and self.command == 'POST':
                if data not in (b'hide', b'show'):
                    status = 400
                else:
                    try:
                        hidden = cover.set_hidden(data == b'hide')
                        status, result = 200, b'hidden' if hidden else b'visible'
                    except RuntimeError as error:
                        status, result = 501, str(error).encode()
            elif self.path == '/frame':
                status, result, mime = 200, frame, 'image/jpeg'
            elif self.path == '/audio':
                status, result, mime, sequence = 200, audio, 'application/octet-stream', serial
            elif self.path == '/input' and self.command == 'POST':
                events = json.loads(data)
                if not isinstance(events,list) or len(events)>128:
                    raise ValueError()
                for event in events:
                    host.session.event(event)
                host.session.last_seen = time.monotonic()
                status = 204
        self.reply(status,result,mime,sequence)

    def handle_request(self):
        try:
            self.route()
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            pass
        except (ValueError, TypeError, RuntimeError):
            self.reply(400)

    do_GET = do_POST = handle_request


def release_idle():
    while True:
        time.sleep(.5)
        with lock:
            if cover.hidden and time.monotonic()-last_frame > 5:
                try:
                    cover.set_hidden(False)
                except RuntimeError:
                    pass
            if time.monotonic()-host.session.last_seen > 2:
                try:
                    host.session.release()
                except RuntimeError:
                    pass


def run():
    global pin
    if os.name != 'nt':
        raise SystemExit('Open Home.cmd on your Windows PC.')
    host.windows = C.WinDLL('user32', use_last_error=True)
    host.windows.SendInput.argtypes = (C.c_uint,C.POINTER(host.Input),C.c_int)
    host.session = host.Session()
    pin = f'{secrets.randbelow(100000000):08d}'
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as probe:
        probe.connect(('192.0.2.1',9))
        ip = probe.getsockname()[0]
    if not ipaddress.ip_address(ip).is_private:
        raise SystemExit('Select a private home-network connection and restart.')
    with ThreadingHTTPServer((ip,0),Handler) as lan, ThreadingHTTPServer(('127.0.0.1',0),Handler) as pc:
        for srv, private in [(lan,False),(pc,True)]:
            srv.local = private
            srv.authority = '%s:%d' % srv.server_address
        url = 'http://' + lan.authority
        print('\nPHONE ADDRESS:',url,'\nPHONE PIN:',pin,'\nUse only on trusted home Wi-Fi. Local traffic uses HTTP. Close this window to end access.',flush=True)
        threading.Thread(target=lan.serve_forever,daemon=True).start()
        threading.Thread(target=release_idle,daemon=True).start()
        host_url='http://'+pc.authority+'/#'+owner
        print('PC host page:',host_url,flush=True)
        webbrowser.open(host_url)
        try:
            pc.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            with lock:
                if cover.hidden:
                    cover.set_hidden(False)
                host.session.release()


if __name__ == '__main__':
    run()
