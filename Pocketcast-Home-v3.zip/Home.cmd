@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto usepython
py -3 home.py
goto end
:usepython
python home.py
:end
if errorlevel 1 echo Install Python 3 from python.org if Windows could not find Python.
pause
