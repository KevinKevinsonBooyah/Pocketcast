"""A capture-excluded blackout overlay on the Windows desktop."""
import ctypes
import os
import queue
import sys
import threading
import time


class MonitorCover:
    def __init__(self):
        self.hidden = False
        self.commands = queue.Queue()
        self.thread = None
        self.error = None

    def set_hidden(self, hidden):
        if os.name != 'nt' or sys.getwindowsversion().build < 19041:
            raise RuntimeError('Hide monitor requires Windows 10 version 2004 or newer.')
        if not self.thread or not self.thread.is_alive():
            self.error = None
            self.thread = threading.Thread(target=self._run, daemon=True)
            self.thread.start()
        done = threading.Event()
        result = []
        self.commands.put((hidden, done, result))
        if not done.wait(3):
            raise RuntimeError(self.error or 'The monitor control did not respond.')
        if result:
            raise RuntimeError(result[0])
        return self.hidden

    def _run(self):
        try:
            import tkinter as tk
            user32 = ctypes.windll.user32
            user32.SetProcessDPIAware()
            user32.SetWindowDisplayAffinity.argtypes = (ctypes.c_void_p, ctypes.c_uint32)
            user32.SetWindowDisplayAffinity.restype = ctypes.c_int
            user32.GetWindowLongPtrW.argtypes = (ctypes.c_void_p, ctypes.c_int)
            user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
            user32.SetWindowLongPtrW.argtypes = (ctypes.c_void_p, ctypes.c_int, ctypes.c_ssize_t)
            user32.SetWindowLongPtrW.restype = ctypes.c_ssize_t
            user32.GetAncestor.argtypes = (ctypes.c_void_p, ctypes.c_uint)
            user32.GetAncestor.restype = ctypes.c_void_p
            window = tk.Tk()
            window.withdraw()
            window.overrideredirect(True)
            window.configure(background='black', cursor='none')
            x = user32.GetSystemMetrics(76)  # Virtual-screen left
            y = user32.GetSystemMetrics(77)
            width = user32.GetSystemMetrics(78)
            height = user32.GetSystemMetrics(79)
            window.geometry(f'{width}x{height}{x:+d}{y:+d}')
            window.update_idletasks()
            hwnd = user32.GetAncestor(window.winfo_id(), 2)
            styles = user32.GetWindowLongPtrW(hwnd, -20)
            # Click-through and no activation keep game input on its window.
            user32.SetWindowLongPtrW(hwnd, -20, styles | 0x20 | 0x08000000 | 0x80)
            if not user32.SetWindowDisplayAffinity(hwnd, 0x11):
                raise RuntimeError('Windows could not exclude the black overlay from screen capture.')
            keys_pressed = False

            def check():
                nonlocal keys_pressed
                while True:
                    try:
                        hidden, done, result = self.commands.get_nowait()
                    except queue.Empty:
                        break
                    try:
                        if hidden:
                            window.deiconify()
                            user32.SetWindowPos(hwnd, -1, x, y, width, height, 0x0010 | 0x0040)
                        else:
                            window.withdraw()
                        self.hidden = hidden
                    except Exception as exc:
                        result.append(str(exc))
                    finally:
                        done.set()
                # Physical keyboard escape in case the phone is unavailable.
                keys = (0x11, 0x12, 0x10, ord('B'))
                pressed = all(user32.GetAsyncKeyState(key) & 0x8000 for key in keys)
                if pressed and not keys_pressed and self.hidden:
                    window.withdraw()
                    self.hidden = False
                keys_pressed = pressed
                window.after(75, check)

            check()
            window.mainloop()
        except Exception as exc:
            self.error = str(exc)
            while True:
                try:
                    _hidden, done, result = self.commands.get_nowait()
                except queue.Empty:
                    break
                result.append(self.error)
                done.set()
