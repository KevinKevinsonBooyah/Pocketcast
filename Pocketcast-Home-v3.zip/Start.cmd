@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto usepython
py -3 host.py
goto end
:usepython
python host.py
:end
if errorlevel 1 echo Install Python 3 from python.org if Windows could not find Python.
pause
