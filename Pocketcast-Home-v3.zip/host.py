"""Pocketcast's foreground, loopback-only Windows input companion."""
import ctypes as C
import hmac
import json
import math
import os
import re
import secrets
import shutil
import subprocess
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DWORD, LONG, WORD = C.c_uint32, C.c_int32, C.c_uint16


class Mouse(C.Structure):
    _fields_ = [('x', LONG), ('y', LONG), ('data', DWORD), ('flags', DWORD),
                ('time', DWORD), ('extra', C.c_size_t)]


class Key(C.Structure):
    _fields_ = [('vk', WORD), ('scan', WORD), ('flags', DWORD),
                ('time', DWORD), ('extra', C.c_size_t)]


class Payload(C.Union):
    _fields_ = [('mouse', Mouse), ('key', Key)]


class Input(C.Structure):
    _fields_ = [('kind', DWORD), ('payload', Payload)]


VK = {f'Key{chr(i)}': i for i in range(65, 91)}
VK.update({f'Digit{i}': 48+i for i in range(10)})
VK.update({f'F{i+1}': 112+i for i in range(12)})
VK.update({
    'Backspace': 8, 'Tab': 9, 'Enter': 13, 'Escape': 27, 'Space': 32,
    'PageUp': 33, 'PageDown': 34, 'End': 35, 'Home': 36, 'ArrowLeft': 37,
    'ArrowUp': 38, 'ArrowRight': 39, 'ArrowDown': 40, 'Insert': 45,
    'Delete': 46, 'ShiftLeft': 160, 'ShiftRight': 161, 'ControlLeft': 162,
    'ControlRight': 163, 'AltLeft': 164, 'AltRight': 165, 'Semicolon': 186,
    'Equal': 187, 'Comma': 188, 'Minus': 189, 'Period': 190, 'Slash': 191,
    'Backquote': 192, 'BracketLeft': 219, 'Backslash': 220, 'BracketRight': 221,
    'Quote': 222, 'CapsLock': 20,
})
BUTTONS = ((2, 4), (32, 64), (8, 16))


def emit(kind, payload):
    item = Input(kind, payload)
    if windows.SendInput(1, C.byref(item), C.sizeof(item)) != 1:
        raise RuntimeError('Windows did not accept the input')


def mouse(flags, dx=0, dy=0, data=0):
    emit(0, Payload(mouse=Mouse(dx, dy, data, flags, 0, 0)))


def key(code, down):
    scan = windows.MapVirtualKeyW(VK[code], 4)
    if not scan:
        return
    flags = 8 | (1 if scan >> 8 else 0) | (0 if down else 2)
    emit(1, Payload(key=Key(0, scan & 255, flags, 0, 0)))


def amount(value, limit):
    if type(value) not in (float, int) or not math.isfinite(value):
        raise ValueError()
    return int(max(-limit, min(limit, value)))


class Session:
    def __init__(self):
        self.lock = threading.Lock()
        self.active = False
        self.keys = set()
        self.buttons = set()
        self.last_seen = 0
        self.last_guess = 0
        self.rotate()

    def rotate(self):
        self.code = f'{secrets.randbelow(100000000):08d}'
        print('Local input approval code:', self.code, flush=True)

    def release(self):
        for code in self.keys.copy():
            key(code, False)
            self.keys.remove(code)
        for button in self.buttons.copy():
            mouse(BUTTONS[button][1])
            self.buttons.remove(button)

    def event(self, event):
        if not isinstance(event, dict):
            raise ValueError()
        kind = event.get('type')
        if kind == 'move':
            mouse(1, amount(event.get('dx'), 2048), amount(event.get('dy'), 2048))
        elif kind == 'wheel':
            mouse(2048, data=-amount(event.get('dy'), 1200))
        elif kind in ('key', 'button'):
            down = event.get('down')
            if type(down) is not bool:
                raise ValueError()
            if kind == 'key':
                value = event.get('code')
                if not isinstance(value, str) or value not in VK:
                    return
                held = self.keys
            else:
                value = event.get('button')
                if type(value) is not int or not 0 <= value < len(BUTTONS):
                    return
                held = self.buttons
            if (value in held) != down:
                if kind == 'key':
                    key(value, down)
                else:
                    mouse(BUTTONS[value][0 if down else 1])
                if down:
                    held.add(value)
                else:
                    held.discard(value)
        elif kind == 'release':
            self.release()
        elif kind != 'heartbeat':
            raise ValueError()


class Signaling:
    def __init__(self):
        self.armed = False
        self.token = secrets.token_urlsafe(32)
        self.clear()
        self.hostname = None
        self.port = None

    def clear(self):
        self.offer = self.answer = self.id = None

    def detect_hostname(self):
        # Recheck after installation or a later sign-in without blocking HTTP.
        while True:
            exe = shutil.which('tailscale') or str(Path(os.environ.get(
                'ProgramFiles', 'C:/Program Files')) / 'Tailscale' / 'tailscale.exe')
            try:
                process = subprocess.run([exe, 'status', '--json'], check=True,
                                         capture_output=True, timeout=5)
                status = json.loads(process.stdout)
                hostname = status['Self']['DNSName'].rstrip('.')
                if (status.get('BackendState') == 'Running' and
                        re.fullmatch(r'[a-zA-Z0-9.-]+', hostname)):
                    self.hostname = hostname
                else:
                    self.hostname = None
            except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError):
                self.hostname = None
            time.sleep(10)

    def config(self):
        return {
            'url': f'https://{self.hostname}:8443/#token={self.token}' if self.hostname else None,
            'port': self.port, 'token': self.token,
            'command': f'tailscale serve --bg --https=8443 http://127.0.0.1:{self.port}',
        }


def description(value, kind):
    if not isinstance(value, dict) or value.get('type') != kind:
        raise ValueError()
    sdp = value.get('sdp')
    if not isinstance(sdp, str) or not sdp.startswith('v=0'):
        raise ValueError()
    return {'type': kind, 'sdp': sdp}


class Handler(BaseHTTPRequestHandler):
    def reply(self, status, body=b'', mime='text/plain'):
        self.send_response(status)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(body)

    def json_reply(self, status, value):
        self.reply(status, json.dumps(value).encode(), 'application/json')

    def read_data(self, limit):
        size = int(self.headers.get('Content-Length', '0'))
        if not 0 < size <= limit or self.headers.get_content_type() != 'application/json':
            raise ValueError()
        return json.loads(self.rfile.read(size))

    def do_GET(self):
        if self.headers.get('Host') != self.server.address:
            return self.reply(403)
        if self.path == '/auto/config':
            return self.json_reply(200, signaling.config())
        if self.path == '/auto/offer':
            with session.lock:
                result = {'offer': signaling.offer, 'id': signaling.id} if signaling.armed and signaling.offer else {}
            return self.json_reply(200, result)
        if self.path.split('?')[0] not in ('/', '/index.html', '/host.html'):
            return self.reply(404)
        self.reply(200, (ROOT/'index.html').read_bytes(), 'text/html; charset=utf-8')

    def do_POST(self):
        if (self.headers.get('Host') != self.server.address or
                self.headers.get('Origin') != 'http://' + self.server.address):
            return self.reply(403)
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= (262144 if self.path == '/auto/answer' else 16384):
                return self.reply(413)
            if self.headers.get_content_type() != 'application/json':
                return self.reply(415)
            data = json.loads(self.rfile.read(size))
            with session.lock:
                status = self.command_result(data)
            self.reply(status)
        except (ValueError, TypeError, OverflowError, RecursionError):
            self.reply(400)
        except RuntimeError:
            self.reply(409)

    def command_result(self, data):
        now = time.monotonic()
        if self.path == '/enable':
            if now - session.last_guess < 0.5:
                return 429
            session.last_guess = now
            if not isinstance(data, dict) or not isinstance(data.get('code'), str):
                return 400
            if not session.code or not hmac.compare_digest(data['code'], session.code):
                return 403
            session.code = ''
            session.last_seen = now
            session.active = True
            print('Remote controls enabled.', flush=True)
        elif self.path == '/auto/arm':
            if not session.active:
                return 403
            signaling.armed = True
            signaling.clear()
        elif self.path == '/auto/disarm':
            signaling.armed = False
            signaling.clear()
        elif self.path == '/auto/answer':
            if not signaling.armed or not isinstance(data, dict) or data.get('id') != signaling.id or not signaling.id:
                return 409
            signaling.answer = description(data.get('answer'), 'answer')
        elif self.path == '/disable':
            signaling.armed = False
            signaling.clear()
            session.release()
            if session.active:
                session.active = False
                session.rotate()
        elif self.path == '/input':
            if not session.active:
                return 403
            events = data if isinstance(data, list) else [data]
            if len(events) > 128:
                return 413
            for event in events:
                session.event(event)
            session.last_seen = now
        else:
            return 404
        return 204

    def log_message(self, *args):
        pass


class PlayerHandler(Handler):
    """Only the player and session negotiation are exposed on the tunnel port."""

    def authorized(self):
        supplied = self.headers.get('Authorization', '')
        return hmac.compare_digest(supplied.encode(), ('Bearer ' + signaling.token).encode())

    def do_GET(self):
        target = urlsplit(self.path)
        if target.path in ('/', '/player.html', '/index.html'):
            try:
                self.reply(200, (ROOT/'player.html').read_bytes(), 'text/html; charset=utf-8')
            except FileNotFoundError:
                self.reply(503, b'Extract the complete Pocketcast companion ZIP first.')
            return
        if target.path != '/auto/answer':
            return self.reply(404)
        if not self.authorized():
            return self.reply(403)
        with session.lock:
            if not signaling.armed:
                status, result = 503, {}
            elif parse_qs(target.query).get('id') != [signaling.id]:
                status, result = 409, {}
            else:
                status, result = 200, {'answer': signaling.answer} if signaling.answer else {}
        self.json_reply(status, result)

    def do_POST(self):
        if self.path != '/auto/offer':
            return self.reply(404)
        if not self.authorized():
            return self.reply(403)
        try:
            body = self.read_data(262144)
            if not isinstance(body, dict):
                raise ValueError()
            offer = description(body.get('offer'), 'offer')
        except (ValueError, TypeError, RecursionError):
            return self.reply(400)
        with session.lock:
            if signaling.armed:
                signaling.offer = offer
                signaling.answer = None
                signaling.id = secrets.token_urlsafe(16)
                status, result = 200, {'id': signaling.id}
            else:
                status, result = 503, {}
        self.json_reply(status, result)


def watchdog():
    while True:
        time.sleep(0.5)
        with session.lock:
            if session.active and time.monotonic() - session.last_seen > 5:
                try:
                    session.release()
                except RuntimeError:
                    continue


if __name__ == '__main__':
    if os.name != 'nt':
        raise SystemExit('Run Start.cmd on your Windows gaming PC.')
    windows = C.WinDLL('user32', use_last_error=True)
    windows.SendInput.argtypes = (C.c_uint, C.POINTER(Input), C.c_int)
    windows.MapVirtualKeyW.argtypes = (C.c_uint, C.c_uint)
    session = Session()
    signaling = Signaling()
    try:
        player = ThreadingHTTPServer(('127.0.0.1', 47978), PlayerHandler)
    except OSError:
        player = ThreadingHTTPServer(('127.0.0.1', 0), PlayerHandler)
    signaling.port = player.server_port
    with player, ThreadingHTTPServer(('127.0.0.1', 0), Handler) as server:
        threading.Thread(target=signaling.detect_hostname, daemon=True).start()
        threading.Thread(target=player.serve_forever, daemon=True).start()
        server.address = '127.0.0.1:' + str(server.server_port)
        url = 'http://' + server.address + '/index.html'
        print('Open this address in Chrome or Edge:', url)
        print('Press Ctrl+C here to stop hosting.', flush=True)
        threading.Thread(target=watchdog, daemon=True).start()
        webbrowser.open(url)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            with session.lock:
                session.release()
